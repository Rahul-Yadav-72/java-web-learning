package com.gmail.service;

public interface EmailService {

	void sendEmail(String to, String name);
}

