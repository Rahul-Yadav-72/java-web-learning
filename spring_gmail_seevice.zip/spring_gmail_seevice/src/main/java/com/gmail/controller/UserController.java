package com.gmail.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.gmail.model.User;
import com.gmail.service.EmailService;

@Controller
public class UserController {

    private final EmailService emailService;

    // ⭐ Constructor Injection
    public UserController(EmailService emailService) {
        this.emailService = emailService;
    }

    @GetMapping("/")
    public String showForm(Model model) {
        model.addAttribute("user", new User());
        return "User-from";
    }

    @PostMapping("/register")
    public String registerUser(@ModelAttribute User user) {

        emailService.sendEmail(user.getEmail(), user.getName());

        return "redirect:/";
    }
}